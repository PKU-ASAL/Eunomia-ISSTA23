inline int CC(x) {return x-1;}

int main() {
    int a, b, c;
    c = CC(a);
    return 0;
}
